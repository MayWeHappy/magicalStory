<script setup lang="ts">
import StoryCreator from "./components/StoryCreator.vue";
</script>

<template>
  <StoryCreator />
</template>

<style>
#app {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}
</style>
